var dbObject = {
    url:"mongodb://localhost/crud"
   
};

module.exports = dbObject;